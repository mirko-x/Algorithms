# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 23:01:38 2024

@author: MScov
"""
            